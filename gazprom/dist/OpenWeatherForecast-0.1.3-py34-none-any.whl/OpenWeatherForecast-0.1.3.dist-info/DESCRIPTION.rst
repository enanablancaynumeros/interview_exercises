Openweather python wrapper to forecast weather data.


