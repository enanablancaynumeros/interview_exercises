import requests
from requests.exceptions import RequestException

from open_weather_forecast.get_info import GetInfo


class GetTemperature(GetInfo):

    pass